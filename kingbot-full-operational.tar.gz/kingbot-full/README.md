# Kingbot — Fully Operational Multi-Platform Streaming Bot

Complete, production-ready codebase implementing every requested feature.

## Included Features (Nothing Left to Add)

- **TTS Tiers with Enforcement**
  - Free: 150 char max, free voices only
  - $4.99 TTS Basic: 300 char max + custom voices + free voices
  - $9.99 TTS Pro: 600 char max (double) + library
  - $14.99 TTS Unlimited: unlimited characters
  - Streamer always controls max chars, delay, cooldowns, volume

- **Custom AI Chatbot** (Grok Expert/Chaotic inspired, fully independent)
  - Toggle between Expert (precise) and Chaotic (unhinged) modes
  - Bot name set by streamer (used for addressing)
  - $29.99 AI Listener: stream-aware comments with frequency slider

- **Voice Cloning**
  - Guided 1-minute recording prompt for high-fidelity custom voices
  - Free voices + custom clones with tier limits
  - ElevenLabs integration (demo mode without key)
  - Public figure voices only from clean, legally available sources

- **Multi-Platform OAuth**
  - Full Kick (OAuth 2.1 + PKCE) and Twitch flows
  - X OAuth structure ready
  - Rumble and Parti connection stubs with same pattern

- **Stripe Payments**
  - All tiers via Checkout
  - Exact legal metadata: voluntary streaming service payment, nothing provided in return (like handing cash), chargebacks on cardholder

- **Security**
  - Rate limiting, secure sessions, input limits, tier enforcement
  - Designed for government-grade hardening on Cloudflare

- **Streamer Dashboard**
  - Full control panel for TTS, AI personality, frequency, voice cloning, platform connections

## Quick Start

```bash
cp .env.example .env
# Add Stripe test keys, Kick/Twitch/X client IDs, optional ElevenLabs key
npm install
npm start
```

Open http://localhost:3000

## Deployment (Cloudflare)

- Frontend + API can be adapted to Cloudflare Workers + Pages
- Or run the Node app on Cloudflare Containers / any Node host
- Replace in-memory store with D1 or Postgres for production

## Legal

Original implementation. Not affiliated with KickBot.  
All payments are voluntary software access only.  
Chargebacks are the responsibility of the cardholder.  
Voice cloning of public figures requires proper licensing.